<?php
// Heading
$_['heading_title'] = 'JivoSite - онлайн консультант';
$_['heading_title2'] = 'JivoSite - онлайн консультант';
$_['menu_title'] = 'JivoSite';

// Text
$_['text_extension'] = 'Модули';
$_['text_success'] = 'Настройки модуля обновлены!';
$_['text_edit'] = 'Редактирование модуля <a target="_blank" style="color:#00bf54; text-decoration:underline" href="https://www.jivosite.ru" >JivoSite - онлайн консультант</a>';
$_['text_edit2'] = '<a target="_blank" style="color:#00bf54; text-decoration:underline" href="https://www.jivosite.ru" >JivoSite - онлайн консультант</a>';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Выключено';

$_['entry_helpm'] = 'Ваш логин для входа в JivoSite';
$_['entry_helpp'] = 'Ваш пароль для JivoSite. Пароль при создании нового аккаунта должен содержать минимум 6 символов, включая одну заглавную букву';
$_['entry_up_text'] = 'Введите ваш e-mail и пароль для аккаунта JivoSite.';
$_['entry_up_text2'] = 'Если у вас его еще нет, то мы автоматически создадим его при сохранении изменений.';
$_['entry_down_text'] = 'Создавая аккаунт JivoSite, вы соглашаетесь с условиями <a href="https://www.jivosite.ru/files/user_registration_aggreement.pdf">пользовательского соглашения</a>, 
лицензионных договоров оферты на <a href="https://www.jivosite.ru/files/contract_offer_sign_free.pdf">Демо версию</a> и <a href="https://www.jivosite.ru/files/contract_offer_sign_paid.pdf">Расширенную версию</a> ПО "JivoSite"';

// Entry
$_['entry_status'] = 'Отображения на сайте';
$_['entry_email'] = 'Email';
$_['entry_userPassword'] = 'Пароль';
$_['entry_userDisplayName'] = 'Оператор';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
$_['error_response'] = 'Error: Нет подключения, попробуйте еще раз';
$_['error_email_validate'] = 'Error: "%s" не является корректным адресом email в формате local-part@hostname';

$_['button_nastr'] = 'Настройки';
$_['button_setup'] = 'Войти или зарегистрироваться';
$_['button_newwind'] = 'Личный кабинет в новом окне';
$_['button_newwind2'] = 'Oткрыть личный кабинет JivoSite в отдельном окне';