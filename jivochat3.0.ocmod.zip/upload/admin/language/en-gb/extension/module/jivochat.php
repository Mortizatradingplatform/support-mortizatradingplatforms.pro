<?php
// Heading
$_['heading_title'] = 'JivoChat - Live Support';
$_['heading_title2'] = 'JivoChat - Live Support';
$_['menu_title'] = 'JivoChat';
// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified JivoChat - online chat module!';
$_['text_edit'] = 'Edit <a target="_blank" style="color:#00bf54; text-decoration:underline" href="https://www.jivochat.com/" >JivoChat - Live Support</a>';
$_['text_edit2'] = '<a target="_blank" style="color:#00bf54; text-decoration:underline" href="https://www.jivochat.com/" >JivoChat - Live Support</a>';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';

$_['entry_helpm'] = 'Your login for JivoChat';
$_['entry_helpp'] = 'Your password for JivoChat. Password for new accounts must be at least 6 characters, and include one uppercase letter';
$_['entry_up_text'] = 'Enter your e-mail address and password for JivoChat account.';
$_['entry_up_text2'] = 'If you don\'t have one we will create it automatically when you save changes.';
$_['entry_down_text'] = 'By proceeding to create a JivoChat account, you are agreeing to our <a href="https://www.jivochat.com/terms/">Terms of service</a>
                                and <a href="https://www.jivochat.com/privacy/">Privacy policy</a>. If you do not agree, you cannot use JivoChat.';

// Entry
$_['entry_status'] = 'Show on site';
$_['entry_email'] = 'Email';
$_['entry_userPassword'] = 'Password';
$_['entry_userDisplayName'] = 'Operator';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify JivoChat - Online Chat module!';
$_['error_response'] = 'Error: No connection, please try again';
$_['error_email_validate'] = 'Error: "%s" is no valid email address in the basic format local-part@hostname';

$_['button_nastr'] = 'Settings';
$_['button_setup'] = 'Login or register';
$_['button_newwind'] = 'My account in new window';
$_['button_newwind2'] = 'Open JivoChat browser-based app';